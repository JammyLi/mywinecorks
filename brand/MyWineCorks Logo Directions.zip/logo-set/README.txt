MyWineCorks logo set — direction 1d

svg/  Scalable masters (fonts embedded). For print or vendors, open in Illustrator/Figma and convert text to outlines.
png/  Raster exports, transparent background except app icons and reversed lockup.

mwc-mark            Bottle mark, for light backgrounds
mwc-mark-reversed   Bottle mark, for dark backgrounds
mwc-lockup          Mark + "My Wine Corks" + tagline, light
mwc-lockup-reversed Same on dark ground (#1b1a18)
mwc-app-icon        1024 full-bleed square (App Store / Play upload; the OS rounds corners)
mwc-app-icon-rounded Rounded preview for web/marketing
mwc-favicon         Simplified mark for 16–64px

Colours: Gold #b68235 (on light) / #d4a560 (on dark), Burgundy #5e1a24, Cork #e6d2ac, Ink #201f1d, Paper #f3f2f2, Night #1b1a18
Type: Cormorant Garamond (name), Lora (tagline, MWC) — both free on Google Fonts.
